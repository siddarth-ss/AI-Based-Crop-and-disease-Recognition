# AI-Based-Crop-and-disease-Recognition-Mobile-App
  A Mobile application developed using Flutter framework which can be deployed in both android and ios.
  The main functionality is to predict the crop image which is being captured from camera or picked from gallery and also be able to recognize the diseases from the crop images.
  Deep learning Convolutional Neural Network is used to learn and predict the crop images. 
  Using Transfer Learning technique, MobilenetV2 model is used and retrained for collected crop and it's disease image dataset.
  Finally this tensorflow model is converted into tensorflow lite model which is used to deploy it in mobile platform.
